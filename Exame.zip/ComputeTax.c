/******************************************************************************/
/*  Copyright (C)sse.ustc.edu.cn,  2014-2015                                  */
/*                                                                            */
/*  FILE NAME              :  menu.c                                          */
/*  PRINCIPAL AUTHOR       :  Xutong                                          */
/*  SUBSYSTM NAME          :  menu                                            */
/*  MODULE NAME            :  menu                                            */
/*  LANGUAGE               :  c                                               */
/*  TARGET ENVIROMENT      :  ANY                                             */
/*  DATE OF FIRST RELEASE  :  2014/10/16                                      */
/*  DESCRIPTION            :  This is a menu program                          */
/******************************************************************************/


/*
* Revision log;
*
* Created by Xutong, 2014/10/16
*
*/

#include <stdio.h>
#include <stdlib.h>
#include "ComputeTax.h"
int TaxRate[5]  = {0.1,0.12,0.15,0.18,0.20};
int Bracket[5]  = {0,10000,20000,30000,40000};
int Base[5]     = {0,1000,2200,3700,55000};

/* ComputeTax program */

int IncomeTax = 0;
int ComputeTax( int Income)
{
	int i;
	int level ;
	for( i = 1 ,level =0 ; i < 5 ;i++)
	{
		if(Income > Bracket[i])
		{
			level = level +1;
		}
		IncomeTax  = Base[level] + TaxRate[level] * (Income - Bracket[level]);
	}
	return IncomeTax;

}
