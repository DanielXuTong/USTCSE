/*  SUBSYSTM NAME          :  menu                                            */
/*  MODULE NAME            :  menu                                            */
/*  LANGUAGE               :  c                                               */
/*  TARGET ENVIROMENT      :  ANY                                             */
/*  DATE OF FIRST RELEASE  :  2014/10/16                                      */
/*  DESCRIPTION            :  This is a menu program                          */
/******************************************************************************/


/*
* Revision log;
*
* Created by Xutong, 2014/10/16
*
*/

#include <stdio.h>
#include <stdlib.h>
#include "ComputeTax.h"
int base[5] = {0,1000,2200,3700,55000};
int main()
{
	int income =0;
	int tax = 0;
	int i;
	printf("please input  income\n");
	scanf("%d",&income);
	tax = ComputeTax(income);
	if(tax < 0)
	{
		exit(0);
	}
	for(i = 0 ; i < 5; i++)
	{
		if(tax == base[i])
		{
			return 0;
		}
		return -1;
		
	}
	printf("%d\n",tax);
	
	
}


