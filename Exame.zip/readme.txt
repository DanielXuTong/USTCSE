This is a menu program!

Build Procedure
    $ gcc ComputeTax.c main.c -o main
    $ ./menu # you can input an income.
