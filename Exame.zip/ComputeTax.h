/******************************************************************************/
/*  Copyright (C)sse.ustc.edu.cn,  2014-2015                                  */
/*                                                                            */
/*  FILE NAME              :  CompueTax.h                                     */
/*  PRINCIPAL AUTHOR       :  Xutong                                          */
/*  SUBSYSTM NAME          :  ComputeTax                                      */
/*  MODULE NAME            :  ComputeTax                                      */
/*  LANGUAGE               :  c                                               */
/*  TARGET ENVIROMENT      :  ANY                                             */
/*  DATE OF FIRST RELEASE  :  2014/10/16                                      */
/*  DESCRIPTION            :  This is a menu program                          */
/******************************************************************************/


/*
* Revision log;
*
* Created by Xutong, 2014/10/16
*
*/

#include<stdio.h>
#include<stdlib.h>

/*
 * Create a ComputeTax
 */

int ComputeTax(int Income);

