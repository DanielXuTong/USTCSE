/**************************************************************************************************/
/*  Copyright (C)sse.ustc.edu.cn,  2014-2015                                                      */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Xutong                                                               */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Xutong, 2014/09/21
 *
 */

#include <stdio.h>
#include <stdlib.h>
#define debug
#include "linktable.h"

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     10

int Help();
int Quit();

/* data struct and its operations */

typedef struct DataNode
{
    tLinkTableNode * pNext;
    char*            cmd;
    char*            desc;
    int              (*handler)();
} tDataNode;

int results[5] = {1,1,1,1,1};
char * info[5] =
{
    "test report",
    "TC1 CreateLinkTable",
	"TC2 AddLinkTableNode",
	"TC3 GetLinkTableHead",
	"TC4 GetNextLinkTableNode",
};

/* find a cmd in the linklist and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head, char * cmd)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
	if(!pNode)
	{
		debug("TC3 GetLinkTableHead");
		results[4] = 1;
	}
    while(pNode)
    {
        if(!strcmp(pNode->cmd, cmd))
        {
            return  pNode;  
        }
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
		if(!pNode)
		{
			debug("TC4 GetNextLinkTableNode");
			results[5] = 1 ;
		}
    }
    return NULL;
}

/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * head)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
	if(!pNode)
	{
		debug("TC3 GetLinkTableHead");
		results[4] = 1;
	}
    while(pNode)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
		if(!pNode)
		{
			debug("TC4 GetNextLinkTableNode");
			results[5] = 1 ;
		}
    }
    return 0;
}

int InitMenuData(tLinkTable ** ppLinktable)
{
    *ppLinktable = CreateLinkTable();
	if(!*ppLinktable)
	{
		debug("TC1 CreateLinkTable");
		results[2] = 1;
	}
    tDataNode* pNode = (tDataNode*)malloc(sizeof(tDataNode));
	if(!pNode)
	{
		printf("the node is empty");
		exit(1);
	}
    pNode->cmd = "help";
    pNode->desc = "Menu List:";
    pNode->handler = Help;
    int q = AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
	if(!q) 
	{
		debug("TC3 AddLinkTableNode");
		results[4] = 1;
	}
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
	if(!pNode)
	{
		printf("the node is empty");
		exit(0);
	}
    pNode->cmd = "version";
    pNode->desc = "Menu Program V1.0";
    pNode->handler = Help; 
    int s = AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
	if(!s)
	{
		debug("TC3 AddLinkTableNode");
		results[4] = 1;
	}
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "quit";
    pNode->desc = "Quit from Menu Program V1.0";
    pNode->handler = Help; 
    int  r = AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
	if(!r)
	{
		debug("TC3 AddLinkTableNode");
		results[4] = 1;
	}
	printf("test report\n");
	int i = 1;
    for( i=1;i<=5;i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number%d F - %s\n",i,info[i]);
        }
    }
	
    return 0; 
}

